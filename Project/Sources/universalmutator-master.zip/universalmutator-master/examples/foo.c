int main () {

  int x,y;
  x = 3;
  y = 4;
  if (x < 10) {
    y += 3;
    x = 22
  }
}
