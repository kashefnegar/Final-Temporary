def handler(tmpMutantName, mutant, sourceFile, uniqueMutants):
    return "VALID"
